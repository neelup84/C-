/*
 * Calculator.cpp
 *
 *  Date: [1/17/21]
 *  Author: [Neelima Patnaik]
 */


#include <iostream>
using namespace std;
//it must be added
int main() //here void convert into int because main must return int
{
char statement[100];
int op1, op2;
char operation;
char answer='Y'; //here forget ; symbol which indicates the line is stop
while(answer=='Y' || answer=='y'){
cout << "Enter expression" <<endl;
cin >> op1 >> operation >> op2;
if (operation=='+')
cout << op1 << " + " << op2<< " = "<< op1 + op2 << endl; //here >> changed to <<
if (operation == '-')
cout << op1 << " - " << op2 << " = " << op1 - op2 << endl; //>> changed to <<
if (operation == '*')
cout << op1 << " * " << op2 << " = " << op1 * op2 << endl; //here ; added
// changed / to *
if (operation == '/')
cout << op1 << " / " << op2 << " = " << op1 / op2 << endl;
//changed * to /
cout << "Do you wish to evaluate another expression? " << endl;
cin >> answer;
}
return 0; //it need to be added for main must return int
}
